package com.ak.coinsbucket.model;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Builder;
import lombok.Data;
import lombok.ToString;

@Data
@Entity
public class Transaction {
	
	@Id
	@GeneratedValue
	private Long id;
	
	@Enumerated(EnumType.STRING)
	private EventType type;
	
	@ManyToOne
    @JoinColumn(name="user_id")
	@ToString.Exclude
	private User user; 
	
	@ManyToOne
    @JoinColumn(name="coin_id")
	@ToString.Exclude
	private Coin coin; 
	
	
	private Double quantity;
	
	private Double rate;
	
    private LocalDateTime lastUpdate;
    

	public Transaction() {

	} 
    
   

}
