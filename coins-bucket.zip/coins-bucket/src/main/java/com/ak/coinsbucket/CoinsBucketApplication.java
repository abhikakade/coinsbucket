package com.ak.coinsbucket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoinsBucketApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoinsBucketApplication.class, args);
	}

}
