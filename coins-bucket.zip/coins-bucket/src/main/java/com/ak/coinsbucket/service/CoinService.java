package com.ak.coinsbucket.service;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.ak.coinsbucket.model.Coin;
import com.ak.coinsbucket.payload.CoinApiResponse;
import com.ak.coinsbucket.repository.CoinRepository;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CoinService {
	
	@Autowired
	CoinRepository coinRepository;
	
	@Autowired
	private RestTemplate restTemplate;
	
	public List<Coin> getAllCoins() {
		List<Coin> coins = coinRepository.findAll(Sort.by(Sort.Direction.ASC, "name"));	
		return coins;
	}
	
	public void refreshCoins() {
		log.info("refreshing coins....");

		try {
			/*
			File file = new ClassPathResource("tickers.json").getFile();
			ObjectMapper objectMapper = new ObjectMapper();
			CoinApiResponse response = objectMapper.readValue(file, CoinApiResponse.class);
			log.info(response.toString());
			*/
			CoinApiResponse response = restTemplate
					  .getForObject("https://api.wazirx.com/api/v2/tickers", CoinApiResponse.class);
			
			if(response != null && response.getAddress().size() > 0) {
				
				response.getAddress().forEach((code, value) -> {
					log.info("Refreshing value for :" + value.getName());
					
					Coin exitingCoin = coinRepository.findByCode(value.getCode());
					if(exitingCoin != null) {
						//perform update
						log.info("updatating ..:");
						exitingCoin.setAt(value.getAt());
						exitingCoin.setBase_unit(value.getBase_unit());
						exitingCoin.setBuy(value.getBuy());
						exitingCoin.setHigh(value.getHigh());
						exitingCoin.setLast(value.getLast());
						exitingCoin.setLow(value.getLow());
						exitingCoin.setVolume(value.getVolume());
						coinRepository.save(exitingCoin);
					}
					else {
						//insert
						log.info("inserintg ..:");
						coinRepository.save(value);
					}
					
				});
				
			}
		} catch (Exception e) {
			log.error(e.getMessage());
		}
	}

	public Coin getCoin(Long coinId) {
		Optional<Coin> coin = coinRepository.findById(coinId);
		return coin.get();
	}
	
	

}
