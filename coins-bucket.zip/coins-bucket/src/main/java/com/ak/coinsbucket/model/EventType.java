package com.ak.coinsbucket.model;

public enum EventType {
	
	BUY,
	SALE

}
