package com.ak.coinsbucket.payload;

import java.time.LocalDateTime;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import com.ak.coinsbucket.model.EventType;

import lombok.Data;

@Data
public class TransactionRequest {

	@NotNull
	private EventType type;

	@NotNull
	private Long user_id; 
	
	@NotNull
	private Long coin_id; 
	
	@NotNull
	@Positive
	private Double quantity;
	
	@NotNull
	@Positive
	private Double rate;
	
	private LocalDateTime lastUpdate;

}
