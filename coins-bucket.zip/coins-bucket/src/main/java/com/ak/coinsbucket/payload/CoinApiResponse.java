package com.ak.coinsbucket.payload;

import java.util.HashMap;
import java.util.Map;

import com.ak.coinsbucket.model.Coin;
import com.fasterxml.jackson.annotation.JsonAnySetter;

import lombok.Data;

@Data
public class CoinApiResponse {

	private Map<String, Coin> address = new HashMap<>();

	@JsonAnySetter
	public void setAddress(String key, Coin value) {
		address.put(key, value);
		address.get(key).setCode(key);
	}

}
