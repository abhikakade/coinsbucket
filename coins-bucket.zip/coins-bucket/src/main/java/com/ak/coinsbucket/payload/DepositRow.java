package com.ak.coinsbucket.payload;

import java.time.LocalDateTime;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DepositRow {
	
	private Long id;
	
	private Long user_id; 

	private double amount;
	
	private LocalDateTime lastUpdate;

}
