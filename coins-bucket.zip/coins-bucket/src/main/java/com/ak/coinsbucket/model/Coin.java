package com.ak.coinsbucket.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Builder;
import lombok.Data;
import lombok.ToString;

@Data
@Entity
public class Coin {
	
	@Id
	@GeneratedValue
	private Long id;
	
	private String code;
	private String name;
	private String base_unit;
	private String quote_unit;
    private double low; 
    private double high;
    private double last;
    private String  type;
    private double open;
    private double volume;
    private double sell;
    private double buy;
    private double at;
    
    @OneToMany(mappedBy = "coin")
	@ToString.Exclude
	@JsonIgnore
	private List<Transaction> transactions;

	public Coin() {

	}

	public Coin(Long id) {
		this.id = id;
	}
    
	public Coin(Long id, String name, Double last, String quote_unit) {
		this.id = id;
		this.name = name;
		this.last = last;
		this.quote_unit = quote_unit;
	}
}
