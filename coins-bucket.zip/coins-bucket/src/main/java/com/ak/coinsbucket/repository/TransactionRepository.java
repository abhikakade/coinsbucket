package com.ak.coinsbucket.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ak.coinsbucket.model.Coin;
import com.ak.coinsbucket.model.Transaction;
import com.ak.coinsbucket.payload.TransactionRow;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long>{

	List<Transaction> findByUserId(Long userId); 
	
	@Query(value = "SELECT "
			+ "new com.ak.coinsbucket.payload.TransactionRow(t.id, t.type, t.user.id, t.coin.id, t.quantity, t.rate, t.lastUpdate)  "
			+ "FROM Transaction t WHERE t.user.id = ?1")
	List<TransactionRow> findUserTransactions(Long userId);

	@Query(value = "SELECT DISTINCT "
			+ "new com.ak.coinsbucket.model.Coin(t.coin.id, t.coin.name, t.coin.last, t.coin.quote_unit) "
			+ "FROM Transaction t WHERE t.user.id = ?1")
	List<Coin> findUserCoins(Long userId);
	
	@Query(value = "SELECT "
			+ "new com.ak.coinsbucket.payload.TransactionRow(t.id, t.type, t.user.id, t.coin.id, t.quantity, t.rate, t.lastUpdate)  "
			+ "FROM Transaction t WHERE t.user.id = ?1 AND t.coin.id = ?2 ORDER BY t.lastUpdate DESC")
	List<TransactionRow> findUserCoinTransactions(Long userId, Long coinId);
	
	@Query(value = "SELECT "
			+ "new com.ak.coinsbucket.payload.TransactionRow(t.id, t.type, t.user.id, t.coin.id, t.quantity, t.rate, t.lastUpdate)  "
			+ "FROM Transaction t WHERE t.user.id = ?1 ORDER BY t.lastUpdate DESC")
	List<TransactionRow> findUserDashboard(Long userId);

}
