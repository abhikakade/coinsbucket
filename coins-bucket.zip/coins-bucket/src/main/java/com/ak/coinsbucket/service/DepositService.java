package com.ak.coinsbucket.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ak.coinsbucket.model.Deposit;
import com.ak.coinsbucket.model.User;
import com.ak.coinsbucket.payload.DepositRequest;
import com.ak.coinsbucket.payload.DepositResponse;
import com.ak.coinsbucket.payload.DepositRow;
import com.ak.coinsbucket.payload.DepositRow.DepositRowBuilder;
import com.ak.coinsbucket.repository.DeositRepository;
import com.ak.coinsbucket.repository.UserRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DepositService {
	
	@Autowired
	DeositRepository deositRepository;
	
	@Autowired
	UserRepository userRepository;

	public DepositRow saveDeposit(@Valid DepositRequest request) {
		
		Optional<User> user = userRepository.findById(request.getUser_id());
		
		Deposit deposit = new Deposit();
		deposit.setUser(user.get());
		deposit.setAmount(request.getAmount());
		deposit.setLastUpdate(request.getLastUpdate());
		
		Deposit savedDeposit = deositRepository.save(deposit);
		
		 DepositRow savedRow = DepositRow.builder().amount(savedDeposit.getAmount())
				 .user_id(savedDeposit.getUser().getId())
		.id(savedDeposit.getId())
		.lastUpdate(savedDeposit.getLastUpdate())
		.build();
		
		return savedRow;
	}

	public DepositResponse getDeposits(Long userId) {
		
		DepositResponse response = new DepositResponse();
		
		List<DepositRow> rowList = new ArrayList<>();
		
		List<Deposit> deposits = deositRepository.findByUserId(userId);
		
		for(Deposit deposit : deposits) {
			
			 DepositRow row = DepositRow.builder().amount(deposit.getAmount())
						.id(deposit.getId())
						.user_id(deposit.getUser().getId())
						.lastUpdate(deposit.getLastUpdate())
						.build();
			 
			 rowList.add(row);
		}
		
		response.setDeposits(rowList);
		
		return response;
		
	}
}
