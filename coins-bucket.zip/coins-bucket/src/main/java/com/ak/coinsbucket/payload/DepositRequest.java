package com.ak.coinsbucket.payload;

import java.time.LocalDateTime;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import lombok.Data;

@Data
public class DepositRequest {
	
	@NotNull
	private Long user_id; 

	@NotNull
	@Positive
	private double amount;
	
	private LocalDateTime lastUpdate;
}
