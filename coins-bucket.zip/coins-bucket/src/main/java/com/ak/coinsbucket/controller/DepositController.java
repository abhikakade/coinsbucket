package com.ak.coinsbucket.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ak.coinsbucket.model.Deposit;
import com.ak.coinsbucket.payload.DepositRequest;
import com.ak.coinsbucket.payload.DepositResponse;
import com.ak.coinsbucket.payload.DepositRow;
import com.ak.coinsbucket.service.DepositService;

@RestController
@RequestMapping("/api/v1/deposit")
public class DepositController {
	
	@Autowired
	DepositService depositService;
	
	@PostMapping
	public ResponseEntity<DepositRow> saveDeposit(@RequestBody @Valid DepositRequest request) throws Exception {

		DepositRow saveDeposit = depositService.saveDeposit(request);
		
		return ResponseEntity.status(HttpStatus.CREATED).body(saveDeposit);
	}
	
	
	@GetMapping("/user/{user_id}")
	public ResponseEntity<DepositResponse> getDeposits(@PathVariable("user_id") Long userId) throws Exception {

		DepositResponse deposits = depositService.getDeposits(userId);
		
		return ResponseEntity.status(HttpStatus.CREATED).body(deposits);
	}

}
