package com.ak.coinsbucket.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ak.coinsbucket.model.Coin;
import com.ak.coinsbucket.model.Deposit;
import com.ak.coinsbucket.model.EventType;
import com.ak.coinsbucket.model.Transaction;
import com.ak.coinsbucket.model.User;
import com.ak.coinsbucket.payload.CoinsResponse;
import com.ak.coinsbucket.payload.DashboardCoin;
import com.ak.coinsbucket.payload.DashboardResponse;
import com.ak.coinsbucket.payload.PortfolioResponse;
import com.ak.coinsbucket.payload.TransactionRequest;
import com.ak.coinsbucket.payload.TransactionResponse;
import com.ak.coinsbucket.payload.TransactionRow;
import com.ak.coinsbucket.repository.CoinRepository;
import com.ak.coinsbucket.repository.DeositRepository;
import com.ak.coinsbucket.repository.TransactionRepository;
import com.ak.coinsbucket.repository.UserRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class TransactionService {
	
	@Autowired
	TransactionRepository transactionRepository;
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	CoinRepository coinRepository;
	
	@Autowired
	DeositRepository deositRepository;
	
	
	public TransactionResponse createTransaction(TransactionRequest transactionRequest) throws Exception {
		
		TransactionResponse response = null;
		
		Optional<User> user = userRepository.findById(transactionRequest.getUser_id());
		Optional<Coin> coin = coinRepository.findById(transactionRequest.getCoin_id());
		
		if(user.isPresent() && coin.isPresent()) {
			
			Transaction record = new Transaction();
			record.setCoin(coin.get());
			record.setUser(user.get());
			record.setType(transactionRequest.getType());
			record.setQuantity(transactionRequest.getQuantity());
			record.setRate(transactionRequest.getRate());
			record.setLastUpdate(transactionRequest.getLastUpdate());
			
			Transaction savedRecord = transactionRepository.save(record);
			
			response = TransactionResponse.builder()
					.id(savedRecord.getId())
					.type(savedRecord.getType())
					.coin_id(savedRecord.getCoin().getId())
					.user_id(savedRecord.getUser().getId())
					.rate(savedRecord.getRate())
					.quantity(savedRecord.getQuantity())
					.lastUpdate(record.getLastUpdate())
					.build();
		}
		else {
			throw new Exception("Invalid user/coin data");
		}
		
		return response;
		
	}


	public PortfolioResponse getUserTransaction(Long userId) {

		List<TransactionRow> records = transactionRepository.findUserTransactions(userId);
		//log.info(records.toString());

		return PortfolioResponse.builder().transactions(records).build();
		//return null;

	}


	public CoinsResponse getUserCoins(Long userId) {
		
		List<Coin> coins = transactionRepository.findUserCoins(userId);
		
		List<Coin> returnList = coins.stream().map(c -> coinRepository.findById(c.getId()).get())
				.collect(Collectors.toList());
		
		return CoinsResponse.builder().coins(returnList).build();
	}


	public PortfolioResponse getUserCoinTransaction(Long userId, Long coinId) {
		
		//get usdt value
		Coin coinUSDT = coinRepository.findAllByCode("usdtinr");
		//current coin details
		Coin coinDetails = coinRepository.findById(coinId).get();
		
		List<TransactionRow> records = transactionRepository.findUserCoinTransactions(userId, coinId);
		
		double totalCoinsBuy = 0D;
		double totalCoinsSold = 0D;
		double totalCoinsHold = 0D;
		
		double totalAmountInvested = 0D;
		double bookedProfit = 0D;
		
		double avgBuyPrice = 0D;
		double avgSalePrice = 0D;
		
		double currentPrice = coinDetails.getLast();
		double highPrice = coinDetails.getHigh();
		double lowPrice = coinDetails.getLow();
		
		double currentProfit = 0D;
		double totalProfit = 0D;
		
		double lastBuyPrice = 0D;
		LocalDateTime lastUpdatePrev = null;
		double maxBuyPrice = 0D;
		
		
		for(TransactionRow row : records ) {

			if(EventType.BUY.toString().equalsIgnoreCase(row.getType().toString())) {
				totalCoinsBuy = totalCoinsBuy + row.getQuantity();
				
				totalAmountInvested = totalAmountInvested + ( row.getQuantity() * row.getRate());
				
				
				if(lastUpdatePrev == null || lastUpdatePrev.isBefore(row.getLastUpdate())) {
					
					lastBuyPrice = row.getRate();
					lastUpdatePrev = row.getLastUpdate();

				}
				
				if(lastBuyPrice < row.getRate()) {
					maxBuyPrice = row.getRate();
				}
				
			}
			
			if(maxBuyPrice > lastBuyPrice) {
				lastBuyPrice = maxBuyPrice;
			}
			
			if(EventType.SALE.toString().equalsIgnoreCase(row.getType().toString())) {
				totalCoinsSold = totalCoinsSold + row.getQuantity();
				
				bookedProfit = bookedProfit + ( row.getQuantity() * row.getRate());
			}
		}
		
		totalCoinsHold = totalCoinsBuy - totalCoinsSold;
		avgBuyPrice = totalAmountInvested / totalCoinsBuy;
		if(bookedProfit > 0) {
			avgSalePrice = bookedProfit / totalCoinsSold;
		}
		currentProfit = totalCoinsHold * currentPrice;
		totalProfit = (currentProfit + bookedProfit) - totalAmountInvested;
		
		
		PortfolioResponse response = PortfolioResponse.builder()
				.totalCoinsBuy(totalCoinsBuy)
				.totalCoinsHold(totalCoinsHold)
				.totalCoinsSold(totalCoinsSold)
				.totalAmountInvested(totalAmountInvested)
				.bookedProfit(bookedProfit)
				.avgBuyPrice(avgBuyPrice)
				.avgSalePrice(avgSalePrice)
				.currentPrice(currentPrice)
				.highPrice(highPrice)
				.lowPrice(lowPrice)
				.currentProfit(currentProfit)
				.totalProfit(totalProfit)
				.lastBuyPrice(lastBuyPrice)
				.transactions(records).build();

		return response;
	}
	
	public DashboardResponse getUserDashboard(Long userId) {
		
		DashboardResponse response = new DashboardResponse();
		List<DashboardCoin> coinRowList = new ArrayList<>();
		
		List<Coin> coins = transactionRepository.findUserCoins(userId);
		
		List<Deposit> deposits = deositRepository.findByUserId(userId);
		
		
		
		//get usdt value
		Coin coinUSDT = coinRepository.findAllByCode("usdtinr");
		
		Double totalInvested = 0D;
		Double portfolioValue = 0D;
		Double portfolioProfit = 0D;
		
		

		for(Coin cn : coins) {
			
			DashboardCoin coinRow = new DashboardCoin();

			List<TransactionRow> records = transactionRepository.findUserCoinTransactions(userId, cn.getId());
			
			Long coinsPurchased = 0L;
			Long coinsSold = 0L;
			Long coinsHold = 0L;
			Double investedAmount = 0D;
			Double currentValue = 0D;
			Double profit = 0D;
			Double coinTotalSellPrice = 0D;
			String rowClass = "";
			
			for(TransactionRow row : records) {
				if(EventType.BUY.toString().equalsIgnoreCase(row.getType().toString())) {
					coinsPurchased = coinsPurchased + row.getQuantity().longValue();
					
					investedAmount = investedAmount + ( row.getQuantity() * row.getRate());
				}
				
				if(EventType.SALE.toString().equalsIgnoreCase(row.getType().toString())) {
					coinsSold = coinsSold + row.getQuantity().longValue();
					
					profit = profit + row.getQuantity() * row.getRate();
					
					
				}
			}
			
			coinsHold = coinsPurchased - coinsSold;
			currentValue = coinsHold * cn.getLast();
			
			
			coinRow.setCoinId(cn.getId());
			coinRow.setCoinName(cn.getName());
			coinRow.setCoinHold(coinsHold);
			coinRow.setInvested(investedAmount);
			coinRow.setCurrentValue(currentValue);
			coinRow.setBookedProfit(profit - investedAmount);
			coinRow.setTotalSale(profit);	
			coinRow.setCurrentProfit(profit + currentValue);
			
			if(coinRow.getBookedProfit() > 0) {
				coinRow.setRowClass("table-success");
			}
			else if(profit == 0) {
				coinRow.setRowClass("table-danger");
			}
			else {
				coinRow.setRowClass("table-warning");
			}
			
			coinRowList.add(coinRow);
			
			
			//TODO add usdt to inr conversion
			if(cn.getQuote_unit().equalsIgnoreCase("usdt")) {
				
				Double usdtValue = coinUSDT.getLast();
				
				portfolioValue = portfolioValue + (investedAmount * usdtValue);
				//totalInvested = totalInvested + (currentValue * usdtValue);
				//portfolioProfit = portfolioValue - totalInvested;
			}
			else {
				
				portfolioValue = portfolioValue + investedAmount;
				//totalInvested = totalInvested + currentValue;
				//portfolioProfit = portfolioValue - totalInvested;
			}
			
			
			coinTotalSellPrice = coinTotalSellPrice + profit;
			
		}
		
		response.setList(coinRowList);
		
		totalInvested = deposits.stream().map(item -> item.getAmount()).collect(Collectors.summingDouble(Double::doubleValue));
		portfolioProfit = portfolioValue - totalInvested;
		
		response.setTotalInvested(totalInvested);
		response.setPortfolioValue(portfolioValue);
		response.setPortfolioProfit(portfolioProfit);

		return response;
	}

}
