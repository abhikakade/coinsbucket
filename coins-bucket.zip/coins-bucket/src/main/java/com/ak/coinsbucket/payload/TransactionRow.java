package com.ak.coinsbucket.payload;

import java.time.LocalDateTime;

import com.ak.coinsbucket.model.EventType;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class TransactionRow {
	

	public Long id;
	
	public EventType type;

	public Long userId; 
	

	public Long coinId; 
	

	public Double quantity;
	
	public Double rate;
	
    public LocalDateTime lastUpdate;

	public TransactionRow(Long id, EventType type, Long userId, Long coinId, Double quantity, Double rate,
			LocalDateTime lastUpdate) {
		super();
		this.id = id;
		this.type = type;
		this.userId = userId;
		this.coinId = coinId;
		this.quantity = quantity;
		this.rate = rate;
		this.lastUpdate = lastUpdate;
	}

	
    
    

}
