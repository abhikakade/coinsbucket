package com.ak.coinsbucket.payload;

import java.util.List;

import com.ak.coinsbucket.model.Coin;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CoinsResponse {
	
	private List<Coin> coins;

}
