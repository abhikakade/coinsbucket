package com.ak.coinsbucket.payload;

import java.util.List;

import lombok.Data;

@Data
public class DashboardResponse {
	
	private Double totalInvested;
	
	private Double portfolioValue;
	
	private Double portfolioProfit;
	
	List<DashboardCoin> list;

}
