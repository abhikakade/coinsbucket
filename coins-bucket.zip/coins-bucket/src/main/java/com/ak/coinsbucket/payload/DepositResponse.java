package com.ak.coinsbucket.payload;

import java.time.LocalDateTime;
import java.util.List;

import lombok.Data;

@Data
public class DepositResponse {
	
	private List<DepositRow> deposits;

}
