package com.ak.coinsbucket.payload;

import java.time.LocalDateTime;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import com.ak.coinsbucket.model.Coin;
import com.ak.coinsbucket.model.EventType;
import com.ak.coinsbucket.model.Transaction;
import com.ak.coinsbucket.model.User;

import lombok.Builder;
import lombok.Data;
import lombok.ToString;

@Data
@Builder
public class TransactionResponse {
	
	private Long id; 
	
	private EventType type;
	
	private Long user_id; 
	
	private Long coin_id; 
	
	private Double quantity;
	
	private Double rate;
	
    private LocalDateTime lastUpdate;

}
