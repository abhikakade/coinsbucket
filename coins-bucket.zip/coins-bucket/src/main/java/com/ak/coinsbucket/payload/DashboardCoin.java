package com.ak.coinsbucket.payload;

import lombok.Builder;
import lombok.Data;

@Data
public class DashboardCoin {
	
	public Long coinId;
	
	public String coinName;
	
	public Long coinHold;
	
	public Double invested;
	
	public Double currentValue;
	
	public Double bookedProfit;
	
	public Double currentProfit;
	
	public Double totalSale;
	
	public String rowClass;
	

}
