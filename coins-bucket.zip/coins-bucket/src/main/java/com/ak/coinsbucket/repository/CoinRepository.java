package com.ak.coinsbucket.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ak.coinsbucket.model.Coin;

@Repository
public interface CoinRepository extends JpaRepository<Coin, Long> {

	Coin findByCode(String code);

	Coin findAllByCode(String string);

}
