package com.ak.coinsbucket.payload;

import java.util.List;

import com.ak.coinsbucket.model.Transaction;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PortfolioResponse {
	
	private double totalCoinsBuy;
	private double totalCoinsSold;
	private double totalCoinsHold;
	
	private double totalAmountInvested;

	
	private double avgBuyPrice;
	private double avgSalePrice;
	
	private double currentPrice;
	private double highPrice;
	private double lowPrice;
	
	private double currentProfit;
	private double bookedProfit;
	private double totalProfit;
	
	private double lastBuyPrice;
	
	private List<TransactionRow> transactions;

}
