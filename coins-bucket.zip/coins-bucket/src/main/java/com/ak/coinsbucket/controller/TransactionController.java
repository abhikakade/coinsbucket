package com.ak.coinsbucket.controller;

import java.util.List;

import javax.validation.Valid;
import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ak.coinsbucket.model.Coin;
import com.ak.coinsbucket.payload.CoinsResponse;
import com.ak.coinsbucket.payload.DashboardResponse;
import com.ak.coinsbucket.payload.PortfolioResponse;
import com.ak.coinsbucket.payload.TransactionRequest;
import com.ak.coinsbucket.payload.TransactionResponse;
import com.ak.coinsbucket.service.TransactionService;

@RestController
@RequestMapping("/api/v1")
public class TransactionController {
	
	@Autowired
	TransactionService transactionService;
	
	@PostMapping("/trade")
	public ResponseEntity<TransactionResponse> makeTrasanction(@RequestBody @Valid TransactionRequest transactionRequest) throws Exception {

		TransactionResponse response = transactionService.createTransaction(transactionRequest);
		
		return ResponseEntity.status(HttpStatus.CREATED).body(response);
	}
	
	@GetMapping("/transactions/user/{user_id}")
	public ResponseEntity<PortfolioResponse> getUserTrasanction(@PathVariable("user_id") Long userId) throws Exception {

		PortfolioResponse response = transactionService.getUserTransaction(userId);
		
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}
	
	@GetMapping("/transactions/user/{user_id}/coin/{coin_id}")
	public ResponseEntity<PortfolioResponse> getUserTrasanction(@PathVariable("user_id") Long userId,
			@PathVariable("coin_id") Long coinId) throws Exception {

		PortfolioResponse response = transactionService.getUserCoinTransaction(userId, coinId);
		
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}
	
	@GetMapping("/user/{user_id}/coins")
	public ResponseEntity<CoinsResponse> getUserCoins(@PathVariable("user_id") Long userId) throws Exception {

		CoinsResponse response = transactionService.getUserCoins(userId);
		
		
		return ResponseEntity.status(HttpStatus.OK).body(response);
		//return null;
	}
	
	@GetMapping("/dashboard/user/{user_id}")
	public ResponseEntity<DashboardResponse> getUserDashboard(@PathVariable("user_id") Long userId) throws Exception {

		DashboardResponse userDashboardResponse = transactionService.getUserDashboard(userId);
		
		return ResponseEntity.status(HttpStatus.OK).body(userDashboardResponse);
	}

}
