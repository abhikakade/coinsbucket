import React, { useEffect, useState } from "react"
import { useParams, Link } from "react-router-dom"
import LoadingDotsIcon from "./LoadingDotsIcon"
import Axios from "axios"

function ProfilePosts() {
  const [iseLoading, setIsLoading] = useState(true)
  const [posts, setPosts] = useState([])
  const { username } = useParams()

  useEffect(() => {
    async function fetchPosts() {
      try {
        const response = await Axios.get(`/profile/${username}/posts`)
        setPosts(response.data)
        setIsLoading(false)
        console.log(response.data)
      } catch (e) {
        console.log("There was a problem in posts.")
      }
    }

    fetchPosts()
  }, [])

  if (iseLoading)
    return (
      <div>
        <LoadingDotsIcon />
      </div>
    )

  return (
    <div className="list-group">
      {posts.map(post => {
        const date = new Date(post.createdDate)
        const formattedDate = `${date.getMonth() + 1}/${date.getDate()}/${date.getFullYear()}`

        return (
          <Link key={post._id} to={`/post/${post._id}`} className="list-group-item list-group-item-action">
            <img className="avatar-tiny" src={post.author.avatar} /> <strong>{post.title} </strong>
            <span className="text-muted small">on {formattedDate} </span>
          </Link>
        )
      })}
    </div>
  )
}

export default ProfilePosts
