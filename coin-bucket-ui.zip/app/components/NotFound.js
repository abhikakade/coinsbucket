import React, { useEffect } from "react"
import Page from "./Page"
import { Link } from "react-router-dom"

function NotFound() {
  return (
    <Page title="Not Found">
      <div className="center">We cannot found page</div>
      <p className="lea text-muted">
        Visit <Link to={`/`}>Home</Link>
      </p>
    </Page>
  )
}

export default NotFound
