import React, { useEffect, useState, useContext } from "react"
import { useParams, Link } from "react-router-dom"
import DatePicker from "react-datepicker"
import LoadingDotsIcon from "./LoadingDotsIcon"
import { withRouter } from "react-router-dom"
import DispatchContext from "../DispatchContext"
import StateContext from "../StateContext"
import Axios from "axios"

import "react-datepicker/dist/react-datepicker.css"

function AddCoin(props) {
  const appDispatch = useContext(DispatchContext)
  const appState = useContext(StateContext)

  const [iseLoading, setIsLoading] = useState(true)
  const [coins, setCoins] = useState([])

  const { userid } = useParams()
  const [coin, setCoin] = useState()
  const [rate, setRate] = useState()
  const [quantity, setQuantity] = useState()
  const [type, setType] = useState()
  const [lastUpdate, setLastUpdate] = useState(new Date())

  useEffect(() => {
    async function fetchCoins() {
      try {
        const response = await Axios.get(`/api/v1/coins`)
        setCoins(response.data)
        setIsLoading(false)
        console.log(response.data)
      } catch (e) {
        console.log("There was a problem in coins.")
      }
    }
    fetchCoins()
  }, [])

  async function handleSubmit(e) {
    e.preventDefault()
    try {
      const response = await Axios.post("/api/v1/trade", { type, user_id: userid, coin_id: coin, quantity, rate, lastUpdate })
      console.log(response)
      appDispatch({ type: "flashMessage", value: "Congrats, coin is added to list." })
      props.history.push(`/transactions/${userid}/coin/${coin}`)
      console.log("New post was created.")
    } catch (e) {
      console.log("There was a problem.")
    }
  }

  if (iseLoading)
    return (
      <div>
        <LoadingDotsIcon />
      </div>
    )

  return (
    <div className="container">
      <form onSubmit={handleSubmit}>
        <div className="form-row">
          <div className="form-group col-md-4">
            <label htmlFor="trans-coin-id">Coin</label>
            <select id="trans-coin-id" className="form-control" name="coin_id" onChange={e => setCoin(e.target.value)}>
              <option>Choose...</option>

              {coins.map(coin => {
                {
                  return (
                    <option value={coin.id} key={coin.id}>
                      {coin.name}
                    </option>
                  )
                }
              })}
            </select>
          </div>
        </div>
        <div className="form-row">
          <div className="form-group col-md-4">
            <label htmlFor="trans-type">Transaction Type</label>
            <select id="trans-type" className="form-control" name="type" onChange={e => setType(e.target.value)}>
              <option>Choose...</option>
              <option>BUY</option>
              <option>SALE</option>
            </select>
          </div>
          <div className="form-group col-md-4">
            <label htmlFor="trans-rate">Rate</label>
            <input type="text" className="form-control" id="trans-rate" name="rate" onChange={e => setRate(e.target.value)} />
          </div>
          <div className="form-group col-md-4">
            <label htmlFor="trans-quantity">Quantity</label>
            <input type="text" className="form-control" id="trans-quantity" name="quantity" onChange={e => setQuantity(e.target.value)} />
          </div>
        </div>
        <div className="form-row">
          <div className="form-group col-md-4">
            <label htmlFor="trans-lastUpdate-id">Date</label>
            <DatePicker selected={lastUpdate} onChange={date => setLastUpdate(date)} className="form-control" />
          </div>
        </div>
        <button type="submit" className="btn btn-primary">
          Add
        </button>
      </form>
    </div>
  )
}

export default withRouter(AddCoin)
