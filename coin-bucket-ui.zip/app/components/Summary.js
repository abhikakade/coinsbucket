import React, { useEffect, useState, useContext } from "react"
import { useParams, Link } from "react-router-dom"
import LoadingDotsIcon from "./LoadingDotsIcon"
import { withRouter } from "react-router-dom"
import Axios from "axios"

function Summary(props) {
  const [iseLoading, setIsLoading] = useState(true)
  const [coins, setCoins] = useState([])
  const [summary, setSummary] = useState([])
  const { userid } = useParams()
  const coinCount = 0

  useEffect(() => {
    async function fetchCoins() {
      try {
        const response = await Axios.get(`/api/v1/dashboard/user/${userid}`)
        setCoins(response.data.list)
        setSummary(response.data)
        setIsLoading(false)
        console.log(response.data.list)
      } catch (e) {
        console.log("There was a problem in coins.")
      }
    }

    fetchCoins()
  }, [])

  if (iseLoading)
    return (
      <div>
        <LoadingDotsIcon />
      </div>
    )

  function handleSubmit(e) {
    e.preventDefault()
    console.log("redirecting to add coin page.")
    try {
      console.log("redirecting to add coin page.")
      props.history.push(`/coin/${userid}/add`)
    } catch (e) {
      console.log("There was a problem in redirecting to add coin page.")
    }
  }

  const renderWrapper = () => {
    if (isLoggedIn) {
      return <button>Logout</button>
    } else {
      return <button>Login</button>
    }
  }

  function coinDetails(coinid) {
    return function (e) {
      e.preventDefault()
      console.log("redirecting to coin details page.")
      try {
        props.history.push(`/transactions/${userid}/coin/${coinid}`)
      } catch (e) {
        console.log("There was a problem in redirecting to add coin page.")
      }
    }
  }

  return (
    <div className="container">
      <div className="card-deck mb-3 text-center">
        <div className="card mb-4 shadow-sm">
          <div className="card-header">
            <h4 className="my-0 font-weight-normal">Total Invested</h4>
          </div>
          <div className="card-body">
            <h1 className="card-title pricing-card-title">{summary.totalInvested.toFixed(2)}</h1>
            <ul className="list-unstyled mt-3 mb-4"></ul>
          </div>
        </div>
        <div className="card mb-4 shadow-sm">
          <div className="card-header">
            <h4 className="my-0 font-weight-normal">Portfolio Value</h4>
          </div>
          <div className="card-body">
            <h1 className="card-title pricing-card-title">{summary.portfolioValue.toFixed(2)}</h1>
            <ul className="list-unstyled mt-3 mb-4"></ul>
          </div>
        </div>
        <div className="card mb-4 shadow-sm">
          <div className="card-header">
            <h4 className="my-0 font-weight-normal">Portfolio Profit</h4>
          </div>
          <div className="card-body">
            <h1 className="card-title pricing-card-title">{summary.portfolioProfit.toFixed(2)}</h1>
            <ul className="list-unstyled mt-3 mb-4"></ul>
          </div>
        </div>
      </div>
      <button onClick={handleSubmit} type="button" className="btn btn-success mt-md-3 mb-md-3">
        Add Coin to Dashboard
      </button>
      <div className="table-responsive">
        <table className="table table-striped">
          <thead>
            <tr>
              <th scope="col">Name</th>
              <th scope="col">Coin Hold</th>
              <th scope="col">Invested</th>
              <th scope="col">Current Value</th>
              <th scope="col">Total Sell</th>
              <th scope="col">Booked Profit</th>
              <th scope="col">Current Profit</th>
              <th scope="col"></th>
            </tr>
          </thead>
          <tbody>
            {coins.map(coin => {
              return (
                <tr key={coin.coinId} className={coin.rowClass}>
                  <td>{coin.coinName}</td>
                  <td>{coin.coinHold}</td>
                  <td>{coin.invested.toFixed(4)}</td>
                  <td>{coin.currentValue.toFixed(4)}</td>
                  <td>{coin.totalSale.toFixed(4)}</td>
                  <td>{coin.bookedProfit.toFixed(4)}</td>
                  <td>{coin.currentProfit.toFixed(4)}</td>
                  <td>
                    <button onClick={coinDetails(coin.coinId)} type="button" className="btn btn-primary">
                      Details
                    </button>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default withRouter(Summary)
