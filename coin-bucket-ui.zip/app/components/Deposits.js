import React, { useContext, useEffect, useState } from "react"
import { useImmerReducer } from "use-immer"
import { useParams, Link, withRouter } from "react-router-dom"
import DatePicker from "react-datepicker"

import "react-datepicker/dist/react-datepicker.css"
import Axios from "axios"
import Page from "./Page"
import LoadingDotsIcon from "./LoadingDotsIcon"
import StateContext from "../StateContext"
import DispatchContext from "../DispatchContext"
import NotFound from "./NotFound"
import TransHeader from "./TransHeader"

function Deposits(props) {
  const appState = useContext(StateContext)
  const appDispatch = useContext(DispatchContext)

  const OriginalList = {
    deposits: [],
    isFetching: true,
    isSaving: false,
    sendCount: 0,
    notFound: false,
    userid: useParams().userid,
    coinDetails: [],
    deposit: {
      user_id: useParams().userid,
      amount: 0,
      lastUpdate: new Date()
    }
  }

  function OurReducer(draft, action) {
    switch (action.type) {
      case "fetchDepositsComplete":
        draft.isFetching = false
        draft.deposits = action.value.deposits
        return
      case "notFound":
        draft.notFound = true
        return
      case "amountChange":
        draft.deposit.amount = action.value
        return
      case "lastUpdateChange":
        draft.deposit.lastUpdate = action.value
        return
      case "submitRequest":
        draft.sendCount++
        return
      case "updateDeposits":
        draft.deposits.push(action.value)
        return
    }
  }

  const [state, dispatch] = useImmerReducer(OurReducer, OriginalList)

  //fetch coin details
  useEffect(() => {
    const ourRequest = Axios.CancelToken.source()

    async function fetchDeposits() {
      try {
        const response = await Axios.get(`/api/v1/deposit/user/${state.userid}`, { cancelToken: ourRequest.token })
        console.log(response.data)
        if (response.data) {
          dispatch({ type: "fetchDepositsComplete", value: response.data })
        } else {
          dispatch({ type: "notFound", value: true })
        }
      } catch (e) {
        console.log(e)
        console.log("There was a problem in fetching coin detials.")
      }
    }

    fetchDeposits()
    return () => ourRequest.cancel()
  }, [])

  function backToSummary(e) {
    e.preventDefault()
    console.log("redirecting to add coin page.")
    try {
      console.log("redirecting to add coin page.")
      props.history.push(`/user/${state.userid}/summary`)
    } catch (e) {
      console.log("There was a problem in redirecting to Home page.")
    }
  }

  function handleSubmit(e) {
    e.preventDefault()
    dispatch({ type: "submitRequest" })
  }

  //add new deposit
  useEffect(() => {
    if (state.sendCount) {
      const ourRequest = Axios.CancelToken.source()

      async function addDeposit() {
        try {
          const response = await Axios.post(`/api/v1/deposit`, { amount: state.deposit.amount, user_id: state.deposit.user_id, lastUpdate: state.deposit.lastUpdate }, { cancelToken: ourRequest.token })
          dispatch({ type: "updateDeposits", value: response.data })
          appDispatch({ type: "flashMessage", value: "New Deposit Added!!" })
          console.log(response.data)
        } catch (e) {
          console.log(e)
          console.log("There was a problem in adding deposit.")
        }
      }

      addDeposit()
      return () => ourRequest.cancel()
    }
  }, [state.sendCount])

  return (
    <Page title="Deposits">
      <div className="container">
        <button onClick={backToSummary} type="button" className="btn btn-primary  mt-md-3 mb-md-3">
          Back To Summary
        </button>

        <form onSubmit={handleSubmit}>
          <div className="form-row">
            <div className="form-group col-md-4">
              <label htmlFor="deposit-amount">Amount</label>
              <input type="text" className="form-control" id="deposit-amount" name="amount" onChange={e => dispatch({ type: "amountChange", value: e.target.value })} />
            </div>
          </div>
          <div className="form-row">
            <div className="form-group col-md-4">
              <label htmlFor="deposit-lastUpdate-id">Date</label>
              <DatePicker selected={state.deposit.lastUpdate} onChange={date => dispatch({ type: "lastUpdateChange", value: date })} className="form-control" />
            </div>
          </div>
          <button type="submit" className="btn btn-primary">
            Add
          </button>
        </form>

        <table className="table table-striped">
          <thead>
            <tr>
              <th scope="col">Date</th>
              <th scope="col">Amount</th>
            </tr>
          </thead>
          <tbody>
            {state.deposits.map(deposit => {
              const date = new Date(deposit.lastUpdate)
              const formattedDate = `${date.getMonth() + 1}/${date.getDate()}/${date.getFullYear()}`

              return (
                <tr key={deposit.id}>
                  <th scope="row">{formattedDate}</th>
                  <td>{deposit.amount}</td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </Page>
  )
}

export default withRouter(Deposits)
