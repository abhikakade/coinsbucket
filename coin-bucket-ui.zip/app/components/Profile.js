import React, { useEffect, useContext } from "react"
import Page from "./Page"
import { useParams } from "react-router-dom"
import StateContext from "../StateContext"
import Axios from "axios"
import ProfilePosts from "./ProfilePosts"
import { useImmer } from "use-immer"

function Profile() {
  const { username } = useParams()
  const appState = useContext(StateContext)
  const [state, setState] = useImmer({
    followActionLoading: false,
    startFollowinggRequestCount: 0,
    stopFollowingRequestCount: 0,
    profileData: {
      isFollowing: false,
      profileAvatar: "https://gravatar.com/avatar/placeholder?s=128",
      profileUsername: "...",
      counts: {
        postCount: "",
        followerCount: "",
        followingCount: ""
      }
    }
  })

  useEffect(() => {
    async function fetchData() {
      try {
        const response = await Axios.post(`/profile/${username}`, { token: appState.user.token })
        setState(draft => {
          draft.profileData = response.data
        })
        console.log(response.data)
      } catch (e) {
        console.log("There was a problem.")
      }
    }

    fetchData()
  }, [])

  return (
    <Page title="Profile">
      <h2>
        <img className="avatar-small" src={state.profileData.profileAvatar} /> {state.profileData.profileUsername}
        {appState.logge}
      </h2>

      <div className="profile-nav nav nav-tabs pt-2 mb-4">
        <a href="#" className="active nav-item nav-link">
          Posts: {state.profileData.counts.postCount}
        </a>
        <a href="#" className="nav-item nav-link">
          Followers: {state.profileData.counts.followerCount}
        </a>
        <a href="#" className="nav-item nav-link">
          Following: {state.profileData.counts.followingCount}
        </a>
      </div>

      <ProfilePosts />
    </Page>
  )
}

export default Profile
