import React, { useContext, useEffect, useState } from "react"
import { useImmerReducer } from "use-immer"
import { useParams, Link, withRouter } from "react-router-dom"
import DatePicker from "react-datepicker"

import "react-datepicker/dist/react-datepicker.css"
import Axios from "axios"
import Page from "./Page"
import LoadingDotsIcon from "./LoadingDotsIcon"
import StateContext from "../StateContext"
import DispatchContext from "../DispatchContext"
import NotFound from "./NotFound"
import TransHeader from "./TransHeader"

function Transactions(props) {
  const appState = useContext(StateContext)
  const appDispatch = useContext(DispatchContext)

  const OriginalList = {
    summary: {
      totalCoinsBuy: 0,
      totalCoinsSold: 0,
      totalCoinsHold: 0,
      totalAmountInvested: 0,
      avgBuyPrice: 0,
      avgSalePrice: 0,
      currentPrice: 0,
      highPrice: 0,
      lowPrice: 0,
      currentProfit: 0,
      bookedProfit: 0,
      totalProfit: 0,
      lastBuyPrice: 0,
      transactions: []
    },
    transactions: [],
    isFetching: true,
    isSaving: false,
    sendCount: 0,
    notFound: false,
    userid: useParams().userid,
    coinid: useParams().coinid,
    coinDetails: [],
    trade: {
      type: "",
      user_id: useParams().userid,
      coin_id: useParams().coinid,
      quantity: 0,
      rate: 0,
      lastUpdate: new Date()
    }
  }

  function OurReducer(draft, action) {
    console.log(action.type)
    switch (action.type) {
      case "fetchComplete":
        draft.isFetching = false
        draft.transactions = action.value.transactions
        draft.summary = action.value
        console.log(draft.summary)
        return
      case "fetchCoinComplete":
        draft.isFetching = false
        draft.coinDetails = action.value
        return
      case "notFound":
        draft.notFound = true
        return
      case "typeChange":
        draft.trade.type = action.value
        return
      case "rateChange":
        draft.trade.rate = action.value
        return
      case "quantityChange":
        draft.trade.quantity = action.value
        return
      case "lastUpdateChange":
        draft.trade.lastUpdate = action.value
        return
      case "submitRequest":
        draft.sendCount++
        return
      case "updateTransactions":
        draft.transactions.push(action.value)
        return
    }
  }

  const [state, dispatch] = useImmerReducer(OurReducer, OriginalList)

  //fetch coin details
  useEffect(() => {
    const ourRequest = Axios.CancelToken.source()

    async function fetchCoinDetails() {
      try {
        const response = await Axios.get(`/api/v1/coins/${state.coinid}`, { cancelToken: ourRequest.token })
        console.log(response.data)
        if (response.data) {
          dispatch({ type: "fetchCoinComplete", value: response.data })
        } else {
          dispatch({ type: "notFound", value: true })
        }
      } catch (e) {
        console.log(e)
        console.log("There was a problem in fetching coin detials.")
      }
    }

    fetchCoinDetails()
    return () => ourRequest.cancel()
  }, [])

  //fetch transactions
  useEffect(() => {
    const ourRequest = Axios.CancelToken.source()

    async function fetchTransactions() {
      try {
        const response = await Axios.get(`/api/v1/transactions/user/${state.userid}/coin/${state.coinid}`, { cancelToken: ourRequest.token })
        console.log(response.data)
        if (response.data) {
          dispatch({ type: "fetchComplete", value: response.data })
        } else {
          dispatch({ type: "notFound", value: true })
        }
      } catch (e) {
        console.log(e)
        console.log("There was a problem in fetching transactions.")
      }
    }

    fetchTransactions()
    return () => ourRequest.cancel()
  }, [])

  //add new transaction
  useEffect(() => {
    if (state.sendCount) {
      const ourRequest = Axios.CancelToken.source()

      async function addTransaction() {
        try {
          const response = await Axios.post(`/api/v1/trade`, { type: state.trade.type, user_id: state.trade.user_id, coin_id: state.trade.coin_id, quantity: state.trade.quantity, rate: state.trade.rate, lastUpdate: state.trade.lastUpdate }, { cancelToken: ourRequest.token })
          dispatch({ type: "updateTransactions", value: response.data })
          appDispatch({ type: "flashMessage", value: "New Trnsaction Added!!" })
          console.log(response.data)
        } catch (e) {
          console.log("There was a problem in adding transaction.")
        }
      }

      addTransaction()
      return () => ourRequest.cancel()
    }
  }, [state.sendCount])

  function handleSubmit(e) {
    e.preventDefault()
    dispatch({ type: "submitRequest" })
  }

  function backToSummary(e) {
    e.preventDefault()
    console.log("redirecting to add coin page.")
    try {
      console.log("redirecting to add coin page.")
      props.history.push(`/user/${state.userid}/summary`)
    } catch (e) {
      console.log("There was a problem in redirecting to Home page.")
    }
  }

  if (state.notFound) return <NotFound />

  if (state.isFetching)
    return (
      <Page title="..">
        <LoadingDotsIcon />
      </Page>
    )

  return (
    <Page title="Transaction Summary">
      <div className="container">
        <button onClick={backToSummary} type="button" className="btn btn-primary">
          Back To Summary
        </button>
        <h2>
          {state.coinDetails.name} (Last Buy Price: {state.summary.lastBuyPrice.toFixed(4)})
        </h2>
        <TransHeader coinDetails={state.summary} />

        <form onSubmit={handleSubmit}>
          <div className="form-row">
            <div className="form-group col-md-4">
              <label htmlFor="trans-type">Transaction Type</label>
              <select id="trans-type" className="form-control" name="type" onChange={e => dispatch({ type: "typeChange", value: e.target.value })}>
                <option>Choose...</option>
                <option>BUY</option>
                <option>SALE</option>
              </select>
            </div>
            <div className="form-group col-md-4">
              <label htmlFor="trans-rate">Rate</label>
              <input type="text" className="form-control" id="trans-rate" name="rate" onChange={e => dispatch({ type: "rateChange", value: e.target.value })} />
            </div>
            <div className="form-group col-md-4">
              <label htmlFor="trans-quantity">Quantity</label>
              <input type="text" className="form-control" id="trans-quantity" name="quantity" onChange={e => dispatch({ type: "quantityChange", value: e.target.value })} />
            </div>
          </div>
          <div className="form-row">
            <div className="form-group col-md-4">
              <label htmlFor="trans-lastUpdate-id">Date</label>
              <DatePicker selected={state.trade.lastUpdate} onChange={date => dispatch({ type: "lastUpdateChange", value: date })} className="form-control" />
            </div>
          </div>
          <button type="submit" className="btn btn-primary">
            Add
          </button>
        </form>

        <table className="table table-striped">
          <thead>
            <tr>
              <th scope="col">Date</th>
              <th scope="col">Type</th>
              <th scope="col">Quantity</th>
              <th scope="col">Rate</th>
              <th scope="col">Total</th>
            </tr>
          </thead>
          <tbody>
            {state.transactions.map(transaction => {
              const date = new Date(transaction.lastUpdate)
              const formattedDate = `${date.getMonth() + 1}/${date.getDate()}/${date.getFullYear()}`

              return (
                <tr key={transaction.id}>
                  <th scope="row">{formattedDate}</th>
                  <td>{transaction.type}</td>
                  <td>{transaction.quantity}</td>
                  <td>{transaction.rate}</td>
                  <td>{(transaction.quantity * transaction.rate).toFixed(4)}</td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </Page>
  )
}

export default withRouter(Transactions)
