import React, { useContext, useEffect, useState } from "react"
import { useImmerReducer } from "use-immer"
import { useParams, Link, withRouter } from "react-router-dom"
import Axios from "axios"
import Page from "./Page"
import LoadingDotsIcon from "./LoadingDotsIcon"
import StateContext from "../StateContext"
import DispatchContext from "../DispatchContext"
import NotFound from "./NotFound"

function TransHeader(props) {
  const coinDetails = props.coinDetails

  console.log(coinDetails)

  const percentageMap = []
  var i
  for (i = 30; i <= 100; i = i + 10) {
    const percent = Number((i * coinDetails.lastBuyPrice) / 100) + Number(coinDetails.lastBuyPrice)
    const percentCoin = Number((i * coinDetails.totalCoinsHold) / 100)
    percentageMap.push({
      percentage: i,
      percentageValue: percent.toFixed(4),
      percentageCoin: percentCoin.toFixed(1)
    })
  }

  console.log(percentageMap)
  console.log(coinDetails.totalCoinsHold)

  return (
    <>
      <div className="card-deck mb-3 text-center">
        <div className="card mb-4 shadow-sm">
          <div className="card-header">
            <h4 className="my-0 font-weight-normal">Coins</h4>
          </div>
          <div className="card-body">
            <h1 className="card-title pricing-card-title">{coinDetails.totalCoinsHold.toFixed(2)}</h1>
            <ul className="list-unstyled mt-3 mb-4">
              <li>Total Purchase: {coinDetails.totalCoinsBuy.toFixed(2)}</li>
              <li>Total Sold: {coinDetails.totalCoinsSold.toFixed(2)}</li>
            </ul>
          </div>
        </div>
        <div className="card mb-4 shadow-sm">
          <div className="card-header">
            <h4 className="my-0 font-weight-normal">Invested</h4>
          </div>
          <div className="card-body">
            <h1 className="card-title pricing-card-title">{coinDetails.totalAmountInvested.toFixed(4)}</h1>
            <ul className="list-unstyled mt-3 mb-4">
              <li>Average Buy Price: {coinDetails.avgBuyPrice.toFixed(4)}</li>
              <li>Average Sale Price: {coinDetails.avgSalePrice.toFixed(4)}</li>
            </ul>
          </div>
        </div>
        <div className="card mb-4 shadow-sm">
          <div className="card-header">
            <h4 className="my-0 font-weight-normal">Current</h4>
          </div>
          <div className="card-body">
            <h1 className="card-title pricing-card-title">{coinDetails.currentProfit.toFixed(4)}</h1>
            <ul className="list-unstyled mt-3 mb-4">
              <li>Price: {coinDetails.currentPrice}</li>
              <li>High: {coinDetails.highPrice}</li>
              <li>Low: {coinDetails.lowPrice}</li>
            </ul>
          </div>
        </div>
        <div className="card mb-4 shadow-sm">
          <div className="card-header">
            <h4 className="my-0 font-weight-normal">Profit</h4>
          </div>
          <div className="card-body">
            <h1 className="card-title pricing-card-title">{coinDetails.totalProfit.toFixed(4)}</h1>
            <ul className="list-unstyled mt-3 mb-4">
              <li>Profit Booked: {coinDetails.bookedProfit.toFixed(4)}</li>
              <li>Current Booked: {coinDetails.currentProfit.toFixed(4)}</li>
            </ul>
          </div>
        </div>
      </div>
      <nav aria-label="Page navigation example">
        <ul className="pagination">
          {percentageMap.map(p => {
            return (
              <li className="page-item" key={p.percentage}>
                <a className="page-link" href="#">
                  {p.percentage}%, Value={p.percentageValue}, Coins={p.percentageCoin}
                </a>
              </li>
            )
          })}
        </ul>
      </nav>
    </>
  )
}

export default TransHeader
