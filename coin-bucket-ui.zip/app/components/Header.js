import React, { useState, useContext } from "react"
import { Link } from "react-router-dom"
import HeaderLoggedOut from "./HeaderLoggedOut"
import HeaderLoggedIn from "./HeaderLoggedIn"
import StateContext from "../StateContext"

function Header(props) {
  const appState = useContext(StateContext)

  return (
    <div className="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom shadow-sm">
      <h5 className="my-0 mr-md-auto font-weight-normal">Coins-Bucket</h5>
      <nav className="my-2 my-md-0 mr-md-3">
        <Link to="/" className="p-2 text-dark">
          Home
        </Link>
        <Link to="/user/1/summary" className="p-2 text-dark">
          Dashboard
        </Link>
      </nav>
      <a className="btn btn-outline-primary" href="#">
        Log In
      </a>
    </div>
  )
}

export default Header
