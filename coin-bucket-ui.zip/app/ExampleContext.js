import { createContext } from "react"

const ExampleContext = createContext()

export default ExampleContext
